import * as Sentry from "@sentry/browser";

Sentry.init({
	dsn:
		"https://9523a043c1a34ad1b261c558b4d6a352@o383174.ingest.sentry.io/5273572",
});

export const answer = true;
