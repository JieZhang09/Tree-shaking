import { FaBeer } from 'react-icons/fa';

export const answer = FaBeer.displayName + FaBeer().props.children[0].props.d;