import React from 'react'
import A from './components/A'

const App = () => {
    return <A />
}
export default App